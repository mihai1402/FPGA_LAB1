module Lab1 (
	input wire key1,
	output wire led1
);

assign led1 = key1;

endmodule